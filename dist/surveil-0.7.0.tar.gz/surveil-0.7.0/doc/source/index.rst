
Welcome to Surveil's documentation!
===================================

Table of Contents:

.. toctree::
   :maxdepth: 2

   readme
   getting_started
   project_architecture
   webapi/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
