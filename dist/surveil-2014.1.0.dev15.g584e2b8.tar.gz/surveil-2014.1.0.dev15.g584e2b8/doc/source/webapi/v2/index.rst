==========
V2 Web API
==========

.. toctree::
   :maxdepth: 2

   config
   status
   actions
   bansho
