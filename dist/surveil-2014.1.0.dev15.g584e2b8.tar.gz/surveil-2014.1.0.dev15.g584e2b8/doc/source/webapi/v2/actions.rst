.. docbookrestapi

=======
Actions
=======

acknowledge
===========

.. rest-controller:: surveil.api.controllers.v2.actions.acknowledge:AcknowledgeController
   :webprefix: /v2/actions/acknowledge

downtime
========

.. rest-controller:: surveil.api.controllers.v2.actions.downtime:DowntimeController
   :webprefix: /v2/actions/downtime

types documentation
===================

.. autotype:: surveil.api.datamodel.actions.acknowledgement.Acknowledgement
   :members:

.. autotype:: surveil.api.datamodel.actions.downtime.Downtime
   :members:
