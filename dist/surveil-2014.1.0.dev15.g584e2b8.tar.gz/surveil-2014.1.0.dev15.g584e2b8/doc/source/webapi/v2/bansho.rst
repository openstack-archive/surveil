.. docbookrestapi

======
Bansho
======

.. rest-controller:: surveil.api.controllers.v2.bansho:BanshoController
   :webprefix: /v2/bansho

Config
======

.. rest-controller:: surveil.api.controllers.v2.bansho.config:ConfigController
   :webprefix: /v2/bansho/config
