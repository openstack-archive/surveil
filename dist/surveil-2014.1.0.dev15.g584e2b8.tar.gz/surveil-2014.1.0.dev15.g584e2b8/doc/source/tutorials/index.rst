Tutorials
#########

Using Surveil
-------------

.. toctree::
   :maxdepth: 1

   getting_started
   monitoring_a_host_with_passive_checks

Contributing
------------

.. toctree::
   :maxdepth: 1

   developing_the_api
   running_the_tests

