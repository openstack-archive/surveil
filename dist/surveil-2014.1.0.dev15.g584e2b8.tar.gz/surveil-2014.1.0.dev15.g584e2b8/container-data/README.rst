Container data
==============

When running Surveil with docker-compose-production.yml, this folder will be filled with MongoDB and InfluxDB data.

